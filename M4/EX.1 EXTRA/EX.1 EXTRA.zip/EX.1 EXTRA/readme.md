Calcula si els números són múltiples o no.

Fes un programa que pregunti a l'usuari/ària dos nombres enters al qual anomenaràs dividend i divisor respectivament.

El divisor haurà d'estar comprès entre 2 i 7.

En cas contrari, el programa haurà de mostrar un missatge d'error.

Si el divisor és correcte (2-7) mostra en pantalla si el dividend és múltiple del divisor, o no.
--
Calcula se os números são múltiplos ou não.

Faça um programa que peça ao usuário dois números inteiros que você chamará de dividendo e divisor, respectivamente.

O divisor deve estar entre 2 e 7.

Caso contrário, o programa deve exibir uma mensagem de erro.

Se o divisor estiver correto (2-7) mostra na tela se o dividendo é múltiplo do divisor ou não.