Fer un programa que demani dos números i un operador(+,-,*,/).

Al final, el programa ha d'imprimir per pantalla el resultat de fer l’operació que contingui la variable operador.

Faça um programa que peça dois números e um operador (+,-,*,/).

Ao final, o programa deve imprimir na tela o resultado da execução da operação que contém a variável do operador.