(M4) Ejercicio EXTRA 3. Jugamos a piedra, papel o tijera
let numRandom = Math.floor(Math.random() * (4 - 1)) + 1
Devuelve un número aleatorio entre min incluido (1) y máx. excluido (4).

Escribe un programa que te permita jugar piedra, papel o tijera con el ordenador.

Por a ello el ordenador deberá generar un número aleatorio entre 1 y 3 que represente piedra, papel o tijera respectivamente, y el usuario/a deberá responder a su vez con un número entre el 1 y el 3 tras mostrar la siguiente pantalla:

Jugamos a piedra, papel o tijera:

1. Piedra

2. Papel

3. Tijera

Si el usuario/a indica algún número diferente del solicitado, deberá aparecer el siguiente mensaje:
«Entiendo que no quieres jugar. Adiós»
En caso contrario, indicar el ganador/a de la siguiente manera:

Yo xxx y tu xxx. ¡He ganado!, o Has ganado!

Según sea el caso.

Ejemplo:

«Yo papel y tú tijera. ¡Has ganado!»


## html
input
button
p id 


## js
function
randomNumber
const userNumber
comprobar si userNumber esta entre 1 y 3, si no mensage «Entiendo que no quieres jugar. Adiós»
si el numero esta entre 1 y 3 buscamos en las combinaciones
mostramos resultado si gana el usuario o si es la maquina, o sea empate


