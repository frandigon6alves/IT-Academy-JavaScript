const mes = Number(prompt('Digite un mes'))
const dia = Number(prompt('Digite un dia'))

switch (mes) {
    case 1:
            if (dia >= 20 && dia <=31) {
                document.getElementById("result").innerHTML = "ACUARIO";
            } else if (dia < 20) {
                document.getElementById("result").innerHTML = "CAPRICORNIO";
            }
            else{
                document.getElementById("result").innerHTML = "Ingresa una fecha real.";
            }
            break;
    case 2:
                if (dia >= 19 && dia <=29) {
                    document.getElementById("result").innerHTML = "PISCIS";
                } else if ( dia < 19) {
                    document.getElementById("result").innerHTML = "ACUARIO";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 3:
                if (dia >= 21 && dia <= 31) {
                    document.getElementById("result").innerHTML = "ARIES";
                } else if (dia <21) {
                    document.getElementById("result").innerHTML = "PISCIS";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 4:
                if (dia >= 20 && dia <=30) {
                    document.getElementById("result").innerHTML = "TAURO";
                } else if (dia <20){
                    document.getElementById("result").innerHTML = "ARIES";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 5:
                if (dia >= 21 && dia <= 31) {
                    document.getElementById("result").innerHTML = "GEMINIS";
                } else if (dia <21){
                    document.getElementById("result").innerHTML = "TAURO";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 6:
                if (dia >= 21 && dia <= 30) {
                    document.getElementById("result").innerHTML = "CANCER";
                } else if(dia < 20){
                    document.getElementById("result").innerHTML = "GEMINIS";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 7:
                if (dia >= 23 && dia <=31) {
                    document.getElementById("result").innerHTML = "LEO";
                } else if(dia < 22){
                    document.getElementById("result").innerHTML = "CANCER";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 8:
                if (dia >= 23 && dia <= 31) {
                    document.getElementById("result").innerHTML = "VIRGO";
                } else if(dia < 23) {
                    document.getElementById("result").innerHTML = "LEO";
                }
                else {
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 9:
                if (dia >= 23 && dia <= 30) {
                    document.getElementById("result").innerHTML = "LIBRA";
                } else if(dia < 23){
                    document.getElementById("result").innerHTML = "VIRGO";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 10:
                if (dia >= 22 && dia <=31) {
                    document.getElementById("result").innerHTML = "ESCORPION";
                } else if (dia < 22){
                    document.getElementById("result").innerHTML = "LIBRA";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 11:
                if (dia >= 23 && dia <= 30) {
                    document.getElementById("result").innerHTML = "SAGITARIO";
                } else if (dia < 23) {
                    document.getElementById("result").innerHTML = "ESCORPION";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
                break;
    case 12:
                if (dia >= 22 && dia <= 31) {
                    document.getElementById("result").innerHTML = "CAPRICORNIO";
                } else if (dia < 22){
                    document.getElementById("result").innerHTML = "SAGITARIO";
                }
                else{
                    document.getElementById("result").innerHTML = "Ingresa una fecha real.";
                }
            break;
            }