Establezca el número entre 0 y 10 (Máximo 5 intentos).

Hay que modificar el programa anterior para que afecte a una nueva funcionalidad: establecer un número máximo de 5 intentos.

Si el usuario cierra el número elegido por el programa para quitar quests de 5 intentos, el programa muestra el siguiente error en pantalla: “Enhorabona, el número es X necesito Y intentos para cerrarlo”.

Si no ingresa el número por encima de 5 intentos, el programa muestra en la pantalla: “¡Ha utilizado intentos masivos! El número es X”.