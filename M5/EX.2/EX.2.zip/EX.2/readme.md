Suma de los valores entre dos números.

El programa pide dos números enteros y entonces calcula la suma de los valores comprendidos entre ambos números, incluidos.

Ejemplo: 4 y 6 --> resultado = 4 + 5 + 6 = 15

declaramos variáveis:
const  num1
const num2

const array = []