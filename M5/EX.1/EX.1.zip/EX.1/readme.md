El usuario/a decide cuántas palabras quiere introducir.

1.Hacer un programa que pregunte al usuario por el número (número) de palabras que se quieren introducir en un array.
--> Prompt

2.Una vez que el usuario responda, el programa deberá preguntar por tantas palabras como el número (número) de palabras que ha dicho el usuario que quería introducir.

3.Las palabras se irán guardando en el array y una vez que han sido todas introducidas, se muestran por pantalla.