Comprovar beques:

Hacer loopiong hasta completar la lista:
Pedir datos al usuario para ver si tiene becas
- si tiene, le digo enorabuena y lo guardo en la lista de becados
- si no tiene, le digo lo siento, no tiene becas

const scholarshipList = []
while (scholarshipList.lenght < 6)

mostrar mensaje de max der becados
mostrar lista de becados