Haz un programa que dibuje una L:

Realiza un programa que pinte la letra L por pantalla hecha con asteriscos.
El programa pedirá la altura.

El mástil horizontal de la L tendrá una longitud de la mitad (división entera entre 2) de la altura más uno.