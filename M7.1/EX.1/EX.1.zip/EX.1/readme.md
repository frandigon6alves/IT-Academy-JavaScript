Calcula la mitja de tres notes i indica si has aprovat o suspès

Calcule a média de três notas e indique se você foi aprovado ou reprovado

Crie um programa onde o usuário insere três notas e o programa calcula a média.

Caso a média seja inferior a 5, a seguinte mensagem deve ser exibida na tela: "Você não foi aprovado no curso. Você tem que se recuperar".

Se a média estiver entre 5 e 7 deve aparecer: "Parabéns! Você passou, mas deve continuar praticando."

Se a média for maior que 7 deve aparecer: "Parabéns! Você passou no curso! Vá para o próximo nível!"