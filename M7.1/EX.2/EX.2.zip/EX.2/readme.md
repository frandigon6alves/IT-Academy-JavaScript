Calcule a nota média e indique se foi aprovado ou reprovado (o usuário escolhe quantas deseja inserir)

Um professor deseja calcular as médias das notas de toda a turma. Crie um aplicativo onde o usuário irá inserir um número por tela (o número corresponde ao número de notas que deseja inserir) e o programa solicitará que ele insira as notas de todos os alunos.

Uma vez inseridas as notas, o programa retorna o seguinte:

Se a nota média for menor que 5: "A nota média da turma está suspensa. Os alunos devem tirar suas dúvidas e se esforçar mais."

Se a nota for inferior a 7: "A nota média da turma é boa, mas os alunos devem melhorar o trabalho pessoal."

Em todos os outros casos, a mensagem deve ser: "Parabéns! A nota média da turma corresponde ao esforço realizado."