Suma todos los pares y los impares de un array

Dado un array de números, el programa debe mostrar la suma de todos los números pares y la suma de todos los números impares.