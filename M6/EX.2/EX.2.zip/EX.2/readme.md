Calcula la edad media:

Este programa calcula la edad media de un número de personas introducido por teclado.

Se debe crear una función que se encargue de pedir las edades al usuario y de calcular la edad media.

La función recibirá por parámetro el núm. de personas a las que debe pedir la edad.
La edad de las personas sólo será válida si está comprendida entre 0 y 120 años.
La media de las edades introducidas debe devolverse por la función (return).